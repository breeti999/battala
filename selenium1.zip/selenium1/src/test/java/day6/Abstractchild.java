package day6;

public class Abstractchild extends Abstract{
	public static void main(String[] args) {
		 Abstractchild obj = new  Abstractchild();
		 obj.primeday();
		 obj.PrimeTime();
		
	}
	@Override
	public void PrimeTime() {
		// TODO Auto-generated method stub
		
		System.out.println("sunday special is chicken");
	}
	@Override
	public void checkstatic() {
		// TODO Auto-generated method stub
		
	}

}
