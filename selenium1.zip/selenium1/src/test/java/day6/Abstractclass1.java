package day6;

public class Abstractclass1 extends Abstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void PrimeTime() {
		// TODO Auto-generated method stub
		System.out.println("sunday special is mutton");
		
	}

	@Override
	public void checkstatic() {
		// TODO Auto-generated method stub
		
	}

}
