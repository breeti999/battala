package day6;

public abstract  class Abstract {
		public abstract void PrimeTime();
		public abstract void checkstatic();
		
		
		public void primeday()
		{
			System.out.println("sunday");
		}
		

}
