package day2;

import java.util.Scanner;

public class P1 {
           public static void main(String[] args) 
	       {
	       Scanner scanner = new Scanner(System.in); 
		   String choice = "Y";
		   while (choice.equalsIgnoreCase("Y")) { 
			System.out.print("Enter the first number: "); 
			int num1 = scanner.nextInt(); 
			System.out.print("Enter the second number: "); 
			int num2 = scanner.nextInt(); 
			int sum = num1 + num2; 
			System.out.println("The sum is: " + sum);
			System.out.print("Do you want to continue? (Y/N): "); 
			choice = scanner.next(); } 
		   scanner.close();
		   }
	       }


