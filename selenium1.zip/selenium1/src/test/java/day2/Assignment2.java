package day2;

import java.util.Scanner;

public class Assignment2 {

	             public static void main(String[] args) {
	            	 int a;
			         int b;
			         int c;
			         String value;
		         Scanner sc = new Scanner(System.in); 
		         do {
		  
		         System.out.println("Enter the first number: "); 
					a = sc.nextInt(); 
					System.out.println("Enter the second number: "); 
					b= sc.nextInt(); 
					c= a+b; 
					System.out.println("sum: " +c); 
					
					System.out.println("Do you want to continue(y/n)");
					value=sc.next();
		         }while(value.equalsIgnoreCase("Y"));
		
	               }
	             }
                 


