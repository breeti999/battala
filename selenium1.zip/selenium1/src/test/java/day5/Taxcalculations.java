package day5;

public class Taxcalculations extends Arthimeticoperations{

	public void Taxcal()
	{
		addition();
		subtration();
		multiplication();
		division();
		percentage();
		
	}
}
