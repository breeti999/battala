package day5;

public class SBI implements Learninterface {

	@Override
	public void Updatepan() {
		System.out.println("SBI");
		
	}

	@Override
	public void linkadhar() {
		System.out.println("adhar");
		
	}

	
}
