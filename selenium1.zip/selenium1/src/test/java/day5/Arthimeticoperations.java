package day5;

public class Arthimeticoperations extends Mathsfunctiob{

	

		public void addition()
		{

	}
		public void subtration()
		{

	}
		public void multiplication()
		{

	}
		public void division()
		{

	}
		
}


