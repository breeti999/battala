package day5;

public interface Learninterface {
	//RBI
	public void Updatepan();
	public void linkadhar();
	

}
