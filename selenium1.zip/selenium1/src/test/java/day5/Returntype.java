package day5;

import java.util.Scanner;

public class Returntype {

	public static void main(String[] args) {
		
//		Scanner sc = new Scanner(System.in);
//		int a=sc.nextInt();
//		int b=sc.nextInt();
		Returntype rtype = new Returntype();
//		rtype.addition(30, 40);
//		rtype.addition(10, 40);
//		rtype.addition(a, b);
		
		int x=rtype.addition(30, 40);
		int y=rtype.addition(10, 40);
		rtype.subtraction(x,y);
		rtype.addition(10, 40, 20);

	}

	public int addition(int a , int b)
	{
		
		int c=a+b;
		System.out.println(c);
		return c;
	}
	public int addition(int a , int b, int c)
	{
		
		int d=a+b;
		System.out.println(d);
		return d;
	}
	public void subtraction(int x , int y)
	{
		
		int z=x-y;
		System.out.println(z);
	}
}
