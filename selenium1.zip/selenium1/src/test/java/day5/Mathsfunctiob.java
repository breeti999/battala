package day5;

public class Mathsfunctiob {

		public void percentage()
		{
			percentage();
			
		}
	

}
