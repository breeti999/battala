package day7;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exceptions {

	 public static void main(String[] args) throws InterruptedException {
	    	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
	        ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
	        driver.get("https://demowebshop.tricentis.com/");
	        driver.findElement(By.linkText("Register")).click();
	        driver.findElement(By.id("gender-female")).click();
	        driver.findElement(By.id("FirstName")).sendKeys("battala"); 
	        try {
				driver.findElement(By.id("LastName")).sendKeys("preeti");
				System.out.println("correct");
			}
	        catch (NoSuchElementException e) {
				System.err.println("Element is not found");
			}
	        
	         catch (ElementClickInterceptedException e) {
				System.err.println("Element is not clickable");
			}
	        catch (ElementNotInteractableException e) {
				System.err.println("Element is not interactable");
			}
	        catch (InvalidSelectorException e) {
				System.err.println("Element is not selectable");
			} catch (NoAlertPresentException e) {
				System.err.println("alert is not present");
			}
	        catch (SessionNotCreatedException e) {
				System.err.println("session not created");
			}
	        catch (NoSuchFrameException e) {
				System.err.println("frame is not present");
			}
	        catch (StaleElementReferenceException e) {
				System.err.println("frame is not present");
	        }
	        catch (WebDriverException e) {
				System.err.println("unkown error");
			}
	        
	        
	        
	        driver.findElement(By.id("Email")).sendKeys("preeti13@gmail.com"); //*[@id="Password"]
	        driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("p@gmail");
	        driver.findElement(By.id("ConfirmPassword")).sendKeys("p@gmail");
	        driver.findElement(By.id("register-button")).click();
	        Thread.sleep(3000);
	        String info = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
	        System.out.println(info);
     }

	}


