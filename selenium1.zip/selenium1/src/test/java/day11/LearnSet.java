package day11;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class LearnSet {

	public static void main(String[] args) {
    Set<String> hashSet = new HashSet<String>();  /// Random : ASCII
		hashSet.add("sailaja");
		hashSet.add("keerthi");
		hashSet.add("sailaja");
		hashSet.add("sweeti");
		hashSet.add("Preeti");
		hashSet.add("sweeti");
		hashSet.add(" ");
		
		System.out.println(hashSet);
		
		Set<String> treeSet = new TreeSet<String>();
		
		treeSet.add("Preeti");
		treeSet.add("reeti");
		treeSet.add("battala");
		treeSet.add("eti");
		treeSet.add("Preeti");
		treeSet.add("reet");
		hashSet.add("");
		
		System.out.println(treeSet);

	}

}
