package day11;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class OccuranceInString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		System.out.println("Enter your String");
		
		String myString=sc.next().trim();

		
		Map<Character, Integer> occurance = new HashMap<Character, Integer>();
		
		char[] myChar = myString.toCharArray();
		
		
		// myChar = [g,o,o,g,l,e]  :
		
		
		//  loop1 :  g : else : {g,1}
		// loop 2 :	o : else : {g,1} , {o,1}
		// loop 3 : o : if (yes) : {g,1}, {o,2}
		// loop 4 : g : yes : {g,2} , {0,2}
		//loop 5 : l : no " else : {g,2}, {o,2} , {l,1}
		//loop6 " e : no : else : {g,2}, {o,2} , {l,1}, {e,1}
		
		for(char eachLetter : myChar)
		{
			
			if(occurance.containsKey(eachLetter))
			{
				occurance.put(eachLetter,occurance.get(eachLetter)+1 );
			}else
			{
				occurance.put(eachLetter,1);
			}
			
		}
		
		System.out.println(occurance);
	}

}
