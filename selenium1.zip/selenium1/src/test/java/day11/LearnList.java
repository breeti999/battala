package day11;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LearnList {

	public static void main(String[] args) {
		
		// ArrayList
		
		List<String> arraylist = new ArrayList<String>();
		arraylist.add("preeti");
		arraylist.add("reeti");
		arraylist.add("eeti");
		arraylist.add("reeti");
		System.out.println(arraylist);
		String val=arraylist.get(1);
	    System.out.println(val);
		
		// LinkedlIst
		
		List<String> linkedList = new LinkedList();
		linkedList.add("preeti");
		linkedList.add("reeti");
		linkedList.add("eeti");
		linkedList.add("reeti");
		System.out.println(linkedList);

	}

}
