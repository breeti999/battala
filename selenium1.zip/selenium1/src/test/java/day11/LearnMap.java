package day11;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class LearnMap {

	public static void main(String[] args) {
		// key-value pair
				// key : no duplicates  : set : latest one
				//value : duplicates : list
				// combination of set and list
				
				Map<String, String> hashMap = new HashMap<String, String>();
				
				hashMap.put("sweeti", "Blue");
				hashMap.put("Anjali", "Pink");
				hashMap.put("Anusha", "Pink");
				hashMap.put("preeti", "Red");
				hashMap.put("preeti", "Black");
				hashMap.put("Ravi", "purple");
				
				System.out.println(hashMap);
				
//		Map<String, String> treeMap = new TreeMap<String, String>();
//				
//				treeMap.put("preeti", "Blue");
//				treeMap.put("Anjali", "Pink");
//				treeMap.put("Anusha", "Pink");
//				treeMap.put("color", "Red");
//				treeMap.put("color", "Black");
//				treeMap.put("Ravi", "purple");
//				
//				System.out.println(treeMap);
//
	}

}
