package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Framepromptalert {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
        driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_prompt");
        
//        driver.switchTo().frame(5); // by index, index starts with 0
        
        driver.switchTo().frame("iframeResult"); // by name or id
		     
//        WebElement frame = driver.findElement(By.xpath("//*[@id=\"iframeResult\"]")); // 20 & 21 by webelement
//        driver.switchTo().frame(frame);
  
        driver.findElement(By.xpath("/html/body/button")).click();
        Thread.sleep(3000);
        driver.switchTo().alert().sendKeys("automation");
        driver.switchTo().alert().accept();

        
       
	}

}
