package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alertssimpleconfirmation {

	public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
			ChromeDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
	        driver.get("https://nxtgenaiacademy.com/alertandpopup/");
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//*[@id=\"main\"]/div[2]/div[1]/div/section[3]/div/div[1]/div/div/div/center/button")).click();
	       
	        //Simple alert
	        
	        String info =  driver.switchTo().alert().getText();
	        System.out.println(info);
	        Thread.sleep(3000);
	        driver.switchTo().alert().accept();//change focus to click ok
	       // the return type of one method is object of another method class
	        
	        //Confirmation Alert
	        
//	        driver.findElement(By.name("confirmalertbox")).click();
//	        Thread.sleep(3000);
//	        driver.switchTo().alert().dismiss();
	        
	}

    }
