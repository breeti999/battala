package day3;

import java.util.Scanner;

public class Conditionalifelseswitch {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		System.out.println("enter no");
//		int a=sc.nextInt();
//		if(a>10)
//		{
//			System.out.println("a is greater than 10");
//		}
//		else if(a==10){
//			System.out.println("a is equal than 10");
//		}
//		else
//			{
//			System.out.println("a is less than 10");			
//		}
//		
//	}
//
//}


    // Switch
		
		System.out.println("enter no");
		int a=sc.nextInt();
   switch (a)
{
	case 3:
		System.out.println("value is 3");
		break;
     case 4:
    	 System.out.println("value is 4");
 		break;
 		default:
 			System.out.println("value is default");
 			
}
    	 
	}
	}
