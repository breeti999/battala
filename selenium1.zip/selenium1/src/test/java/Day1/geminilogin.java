package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class geminilogin {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver(); // class name object = new class name
		
		//driver.get("https://purpleid-stage.oktapreview.com/");
		driver.get("https://www.ksgcollege.com/");
		//driver.manage().window().maximize();
		driver.findElement(By.id("okta-signin-username")).sendKeys("4920519");
		driver.findElement(By.id("okta-signin-password")).sendKeys("Mou#ped99@t");
		driver.findElement(By.xpath("//*[@id=\"okta-signin-submit\"]")).click();
		//driver.findElement(By.xpath("//*[@id=\"form67\"]/div[2]/input")).click();
		Thread.sleep(3000);
		//driver.manage().timeouts(10).implicitly
		driver.findElement(By.xpath("//input[@value='Send Push']")).click();
	}

}
