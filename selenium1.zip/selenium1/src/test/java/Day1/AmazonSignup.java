package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonSignup {

	public static void main(String[] args) {

//		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
//		ChromeDriver driver = new ChromeDriver(); // class name object = new class name
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriverManager.chromedriver().capabilities(options).clearDriverCache().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in/");
		String title = driver.getTitle();
		System.out.println(title);
		driver.findElement(By.linkText("Start here.")).click();
		driver.manage().window().maximize();
		String title1 = driver.getTitle();
		System.out.println(title1);
		driver.findElement(By.xpath("//*[@id=\"ap_customer_name\"]")).sendKeys("preeti");
		driver.findElement(By.xpath("//*[@id=\"ap_phone_number\"]")).sendKeys("987654321");
		driver.findElement(By.id("ap_email")).sendKeys("preeti@gamil.com");
		driver.findElement(By.name("password")).sendKeys("123456");
	}
}
