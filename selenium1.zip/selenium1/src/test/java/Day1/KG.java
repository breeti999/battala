package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class KG {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver(); 
		driver.get("https://www.ksgcollege.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\"header-part\"]/div[1]/div/div/div[2]/div/div[2]/ul/li[1]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"exampleInputUsername\"]")).sendKeys("battala@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"exampleInputPassword\"]")).sendKeys("Mou#ped99@t");
		driver.findElement(By.xpath("//*[@id=\"wrapper\"]/div/div/div[2]/div/div/form/button")).click();
	}

}
