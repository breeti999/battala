package day8;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGAnnotation {
@Test
 public void testmethod()
 {
	System.out.println("I am able to do ");
 }
@BeforeMethod

public void beforeMethod()
{
	System.out.println("before method test case");
}
@AfterMethod
public void afterMethod()
{
	System.out.println("after method test case");
}
	@BeforeClass
	public void beforeclass()
	{
		System.out.println("before class test case");
	}
	@AfterClass
	public void afterclass()
	{
		System.out.println("before class test case");
	}
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("before test test case");
	}
	@AfterClass
	public void afterTest()
	{
		System.out.println("after test test case");
		
	}
	@BeforeSuite
	public void beforeSuite()
	{
		System.out.println(" before suite test case");
		
	}
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("after suite test case");
		
	}

	
}