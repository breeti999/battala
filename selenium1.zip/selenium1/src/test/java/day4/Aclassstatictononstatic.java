package day4;

public class Aclassstatictononstatic {

	public static void method1()
	{
		Aclassstatictononstatic a =new Aclassstatictononstatic();
      a.method4();
	}
	public static void method2()
	{
		method1();
	}
	public void method3()
	{
		method2();
	}
	public void method4()
	{
		method3();
	}

	}


