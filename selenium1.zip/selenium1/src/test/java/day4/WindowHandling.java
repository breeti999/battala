package day4;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandling {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	    driver.get("https://www.w3schools.com/python/trypython.asp?filename=demo_default");
	
//	String activesessionid = driver.getWindowHandle();
//	System.out.println("before clicking" +activesessionid);
//    driver.findElement(By.xpath("//*[@id=\"tryhome\"]")).click();
//	String activesessionid1 = driver.getWindowHandle();
//	System.out.println("After clicking" +activesessionid1);
	
		//set- collection
		Set<String> allsessionids=driver.getWindowHandles();
	    System.out.println(allsessionids);
//		
//		// for each : Iterator
//		
//		for(String id: allsessionids) // in lineno 24 allsessionids taken and value is string
//		{
//			System.out.println(id);
	    // driver.switchTo().window(id);		
//			
//		}
//		
//		String activesessionid4 = driver.getWindowHandle();
//		System.out.println("clicking" +activesessionid4); //36 and 37 for for print window 
//		driver.findElement(By.linkText("HTML")).click(); 17 to 41 one 
//		
		
		
		// Iterator 46 to 55
		
	driver.get("https://demowebshop.tricentis.com/");
		driver.switchTo().newWindow(WindowType.WINDOW);
		Set<String> allsessionids5=driver.getWindowHandles();
		Iterator<String> id= allsessionids5.iterator();
		String firstsession=id.next();
		String secondsession=id.next();
		System.out.println(firstsession);
		System.out.println(secondsession);
		 driver.switchTo().window(secondsession);
		 driver.get("https://demowebshop.tricentis.com/books");
		
		

	}

}
