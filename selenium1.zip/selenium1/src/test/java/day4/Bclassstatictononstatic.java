package day4;

public class Bclassstatictononstatic {

	public static void method5()
	{
		Aclassstatictononstatic.method1();
	}
	public static void method6()
	{
		Aclassstatictononstatic a= new Aclassstatictononstatic();
				a.method4();
	}
	public void method7()
	{
		Aclassstatictononstatic.method2();
	}
	public void method8()
	{
		Aclassstatictononstatic a= new Aclassstatictononstatic();
		a.method4();
	}
	}


