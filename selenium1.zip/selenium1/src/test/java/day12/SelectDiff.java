package day12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDiff {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
        ChromeDriver driver = new ChromeDriver();
	    driver.manage().window().maximize();
        driver.get("https://www.irctc.co.in/nget/train-search");
        driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div")).click();
        driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[4]/div/ul/p-dropdownitem[6]/li"));
      
	}

}
