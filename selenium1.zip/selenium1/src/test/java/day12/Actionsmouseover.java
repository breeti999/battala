package day12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actionsmouseover {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
        ChromeDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
        driver.get("https://demowebshop.tricentis.com/");
       Actions action = new Actions(driver);
       WebElement element=driver.findElement(By.linkText("computers"));
       action.moveToElement(element).perform();
       action.clickAndHold().release().perform();
       action.doubleClick().perform();
       action.dragAndDrop(element, element); // here we need to give the elements 
	}

}
