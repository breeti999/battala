package day12;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTable {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
        ChromeDriver driver = new ChromeDriver();
	    driver.manage().window().maximize();
        driver.get("https://erail.in/");
        driver.findElement(By.id("buttonFromTo")).click();
        Thread.sleep(3000);
        WebElement table =driver.findElement(By.tagName("table"));
        List<WebElement> allrows = table.findElements(By.xpath("//*[@id=\"divTrainsList\"]/table[1]/tbody/tr"));
        System.out.println(allrows.size());
      
	   }

       }
