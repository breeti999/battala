package stepdefinition;
import java.time.Duration;
import cucumber.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.Pages;

public class Login extends BaseClass {

	


@Given("user is on Login page")
public void user_is_on_login_page() {
   System.out.println("Hello Pulivendula");
}

@Then("user enters user name and password")
public void user_enters_user_name_and_password() {
   System.out.println(" 4920519 and 1234567");
}

@Then("click on login button")
public void click_on_login_button() {
    System.out.println("click");
}

@Then("user is navigated to the home page")
public void user_is_navigated_to_the_home_page() {
   System.out.println("Navigating");
}

		    
		}

	


