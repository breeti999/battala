package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;



	@RunWith(Cucumber.class)
	@CucumberOptions(
			features = {"C:\\Users\\battala.preeti\\eclipse-workspace\\CucumberPractice\\src\\test\\java\\features\\first.feature"},

			glue = {"stepdefinition"},
			
			//plugin = {"pretty", "html:target/HtmlReports" // html data
					//plugin = {"pretty", "json:target/JsonReports" // Json
	 
//			glue = "stepDefinitions", stepNotifications = true, 
       // plugin = {"pretty", "html:test-output/myreport.html",
//				"json:test-output/myreport.json"})
					//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})
//			tags = "@CICD", dryRun = true, monochrome = true)
	
	plugin = {"html:./reports/cucumber_report.html","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
			
	})
	 
	public class ProjectTest {
	 
		
			}
		

	
