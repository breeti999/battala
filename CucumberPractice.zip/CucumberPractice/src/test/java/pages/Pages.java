package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumber.BaseClass;



public class Pages extends BaseClass {
	public Pages(RemoteWebDriver driver) {
		PageFactory.initElements(driver,this);
		this.driver=driver;
	}
	
	@FindBy(id="session_key")
	WebElement Username;
	
	@FindBy(id = "session_password")
	WebElement password;
	
	public Pages enterUsername(String username) {
		enterValue(Username, username);
		return this;
	}
	
  public Pages enterpassword(String passwordvalue) {
	  
	enterValue(password, passwordvalue);
	return this;
  }

}


