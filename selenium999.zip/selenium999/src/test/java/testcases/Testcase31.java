package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Testcase31 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
        driver.get("https://new.demowebshop.tricentis.com/");
        driver.findElement(By.linkText("Log in")).click();
        driver.findElement(By.id("Email")).sendKeys("preeti13@gmail.com");  
        driver.findElement(By.id("Password")).sendKeys("p@gmail"); 
        driver.findElement(By.xpath("/html/body/div[5]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/input")).click();
        driver.findElement(By.xpath("/html/body/div[5]/div[2]/ul[1]/li[4]/a")).click(); 
        WebElement product =driver.findElement(By.xpath("//*[@id=\"products-orderby\"]"));
        Select option = new  Select(product);
        option.selectByIndex(3);
        driver.findElement(By.xpath("/html/body/div[5]/div[3]/div[2]/div[2]/div/div[2]/div[5]/ul/li[2]/a")).click();
        driver.findElement(By.xpath("/html/body/div[5]/div[3]/div[2]/div[2]/div/div[2]/div[4]/div/div[3]/div/div[2]/div[3]/div[2]/input[1]")).click();
       // Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
        driver.findElement(By.xpath("//*[@id=\"termsofservice\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
//        driver.findElement(By.xpath("")).click();
//        driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
//        driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
        
        WebElement product2= driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]"));
        Select option2 = new  Select(product2);
        option2.selectByVisibleText("India");
        driver.findElement(By.id("BillingNewAddress_City")).sendKeys("Vizag");
         driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys("ap");
         driver.findElement(By.id("BillingNewAddress_Address2")).sendKeys("ap");
          driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys("1234");
          driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_PhoneNumber\"]")).sendKeys("1234");
          driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_FaxNumber\"]")).sendKeys("134");
          driver.findElement(By.xpath(" //*[@id=\"billing-buttons-container\"]/input")).click();
          Thread.sleep(3000);
          driver.findElement(By.xpath("//*[@id=\"shipping-buttons-container\"]/input")).click();
          Thread.sleep(3000);
         driver.findElement(By.xpath(" //*[@id=\"shipping-method-buttons-container\"]/input")).click();
         Thread.sleep(3000);
         driver.findElement(By.xpath("//*[@id=\"CardholderName\"]")).sendKeys("preetiyadav");
         driver.findElement(By.xpath("//*[@id=\"CardNumber\"]")).sendKeys("1239999"); 
         driver.findElement(By.xpath("//*[@id=\"CardCode\"]")).sendKeys("9999");
         
         driver.findElement(By.xpath("//*[@id=\"payment-info-buttons-container\"]/input")).click();
//         Thread.sleep(3000);
//        driver.findElement(By.xpath("//*[@id=\"payment-info-buttons-container\"]/input")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.xpath("//*[@id=\"confirm-order-buttons-container\"]/input")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/div[2]/input")).click();
	}

}
