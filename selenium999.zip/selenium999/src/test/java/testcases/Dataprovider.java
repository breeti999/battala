package testcases;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class Dataprovider {
	@Test(dataProvider ="LoginTestData" ) // there is no LoginTestData directly we can use the method dataprovider loginData

	public void TestLogin(String Username, String Password) throws Exception{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
        ChromeDriver driver = new ChromeDriver();
	    driver.manage().window().maximize();
        driver.get("https://www.linkedin.com/");
        driver.findElement(By.xpath("(//a[contains(text(),'Sign in')])[1]"));
        driver.findElement(By.id("username")).sendKeys(Username);
        driver.findElement(By.id("password")).sendKeys(Password);
        driver.findElement(By.xpath("//button[@class=\"btn__primary--large from__button--floating\"]")).click();
        Thread.sleep(1000);
        driver.quit();
	}
	@DataProvider(name="LoginTestData") // find unique that's why given name for suppose here no name means @Dataprovider() that time we can use method name
	public Object[][] loginData() {
		Object[][] data=new Object[2][2];
		
		data[0][0]="battalapreeti999@gmail.com";
		data[0][1]="Swe#pre9@b";
		
		data[1][0]="battalapreeti1999@gmail.com";
		data[1][1]="Swe#pre9@b";
		return data;
	}
		
		
        
       
}

