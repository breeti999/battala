package testcases;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Printduplicate {

	
		public static void printDuplicateCharacters(String str) {

			// Create a map to store character frequency 
			Map<Character, Integer> charMap = new HashMap<>(); 
			// Iterate through each character in the string
			for (char c : str.toCharArray()) {
				// Increment the frequency count for the character
				charMap.put(c, charMap.getOrDefault(c, 0) + 1); } 
			// Print the duplicate characters from the map 
			System.out.println("Duplicate characters in the string:");
			for (char c : charMap.keySet()) {
				if (charMap.get(c) > 1) { 
					System.out.print(c + " "); } } } 
		  public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in); 
			System.out.print("Enter a string: "); 
			String input = scanner.nextLine(); 
			scanner.close(); 
			printDuplicateCharacters(input); } 
			

	}

