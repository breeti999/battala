package testcases;

import java.io.FileInputStream;

public class XLsheet {
	    static Workbook book;
		static Sheet sheet;
	 
			static String excelfilepath = "E:\\Preeti\\Trackingnumber.xlsx";
			//String tt= "794915534116";
			public static Object[][] getTestData(String sheetName)throws IOException, EncryptedDocumentException, InvalidFormatException
			{
				//Create an object of File class to open Excel file
				 //Create an object of FileInputStream class to read an Excel file
			FileInputStream file = new FileInputStream(excelfilepath); // class creating the object helps to load the xl sheet
			//For xlsx file create object of XSSFWorkbook class
			book = WorkbookFactory.create(file); // work book is xl sheet
			//Read sheet inside the workbook by its name
			sheet = book.getSheet(sheetName);
			//Get total number of rows in the particular Excel Sheet
			Object[][] inputdata = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
			for(int i=0;i<sheet.getLastRowNum();i++)
			{
				for(int j=0;j<sheet.getRow(0).getLastCellNum();j++)
				{
					inputdata[i][j] = sheet.getRow(i+1).getCell(j).toString();
					//System.out.println(inputdata[i][j]);
					//System.out.println(i+"dfgdf"+j+"dfgd");
				}
			}
			return inputdata;
		}
			public static void main(String[] args) throws EncryptedDocumentException, InvalidFormatException, IOException {
				Object[][] inputdata =getTestData("Sheet1");
			}
	 
	}

	

