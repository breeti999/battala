package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

       public class Testcase002 {

	    public static void main(String[] args) throws InterruptedException {
	    	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://demowebshop.tricentis.com/");
	        driver.findElement(By.linkText("Log in")).click();
	        driver.findElement(By.id("Email")).sendKeys("preeti10@gmail.com");  
	        driver.findElement(By.id("Password")).sendKeys("p@gmail"); 
	        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	        String user = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	        System.out.println(user);
	        Thread.sleep(3000);  
	        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a" )).click();
	        driver.findElement(By.xpath(" /html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[1]/div/div/a/img")).click();
	        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/div[3]/div[2]/input")).click();
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-72\"]")).click();
	        Thread.sleep(3000);
	        driver.navigate().back();
	        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[3]/div/div[2]/div[3]/div[2]/input")).click();
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-74\"]")).click();
        
	    }
        }
