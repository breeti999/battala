package testcases;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

        public class Testcase001 {

	    public static void main(String[] args) throws InterruptedException {
	    	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
	        ChromeDriver driver = new ChromeDriver();
		    driver.manage().window().maximize();
	        driver.get("https://demowebshop.tricentis.com/");
	        driver.findElement(By.linkText("Register")).click();
	        driver.findElement(By.id("gender-female")).click();
	        driver.findElement(By.id("FirstName")).sendKeys("battala"); 
			driver.findElement(By.id("LastName")).sendKeys("preeti");
			driver.findElement(By.id("Email")).sendKeys("preeti13@gmail.com"); //*[@id="Password"]
	        driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("p@gmail");
	        driver.findElement(By.id("ConfirmPassword")).sendKeys("p@gmail");
	        driver.findElement(By.id("register-button")).click();
	        Thread.sleep(3000);
	        String info = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
	        System.out.println(info);
        }
        }
