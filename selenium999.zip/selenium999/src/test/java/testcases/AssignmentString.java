package testcases;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AssignmentString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		System.out.println("Enter your String");
		
		String myString=sc.next().trim();

		
		Map<Character, Integer> occurance = new HashMap<Character, Integer>();
		
		char[] myChar = myString.toCharArray();
		for(char eachLetter : myChar)
		{
			
			if(occurance.containsKey(eachLetter))
			{
				occurance.put(eachLetter,occurance.get(eachLetter)+1 );
			}else
			{
				occurance.put(eachLetter,1);
			}
			
		}
		
		System.out.println(occurance);
	}

	}


