package testcases;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

public class Screenshot {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
        ChromeDriver driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://demowebshop.tricentis.com/");
		
		File tmp = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("./screenshots/one"+ time()+".png");
		FileUtils.copyFile(tmp,dest);
	}
	
	
		public static String time() {
			return new SimpleDateFormat("ss-mm-hh-dd-mm-yyyy").format(new Date());
			
		}
		
		// or
		//File DestPath=new File("./Screenshot/one"+System.currentTimeMillis()+".png");
		

	}


