package testcases;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Readingnotepadfromdata {

	public static void main(String[] args) throws IOException {
		String TestFile = "C:\\Users\\ajain153\\Desktop\\testdata.txt";
		FileReader FR = new FileReader(TestFile);
		BufferedReader BR = new BufferedReader(FR);
		String Content = "";

		//Loop to read all lines one by one from file and print It.
		while((Content = BR.readLine())!= null){
			System.out.println(Content);
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
			ChromeDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
	        driver.get("https://new.demowebshop.tricentis.com/");
		}

	}

}
