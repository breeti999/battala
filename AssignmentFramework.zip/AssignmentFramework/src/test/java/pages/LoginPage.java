package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class LoginPage extends BaseClass{
	public LoginPage(RemoteWebDriver driver)
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "okta-signin-username")
	WebElement username;
	@FindBy(id = "okta-signin-password")
	WebElement password;
	@FindBy(id = "okta-signin-submit")
	WebElement loginbutton;
	@FindBy(xpath = "//input[@value='Send Push']")
     WebElement Pushbutton;
	
	@FindBy(xpath = "//select[@id='fx-gn-role-dropdown-SG']")
	public static WebElement country_Dpdn;

	@FindBy(xpath = "//button[@id='btnContextSelection']")
	public WebElement continue_Btn;

	@FindBy(xpath = "//span[@class='btn btn-outline-primary dropdown-toggle tools-icon_tools']")
	public WebElement settings_Btn;

	@FindBy(id = "clear-all")
	public WebElement context_Lnk;

	@FindBy(id = "fx-gn-context-selection_location")
	public WebElement location_Dpdn;
	

	
	public LoginPage enterusername(String usernameValue)
	{
		enterValue(username, usernameValue);
	return this;
}
	public LoginPage enterPassword(String passwordValue)
	{
		enterValue(password, passwordValue);
	return this;
	
}
	public HomeUser clickLoginbutton()
	{
		clickElement(loginbutton);
		return new HomeUser();  
	}
	public HomeUser pushbutton()
	{
		clickElement(Pushbutton);
		return new HomeUser();  
	}
	
	public void select_Country() throws InterruptedException {
		Thread.sleep(3000);
		waitTillElementVisible(country_Dpdn);
		WebElement drop = country_Dpdn;
		drop.click();
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		scrollByUsingJavaScript();
		Thread.sleep(3000);
	}

	private void scrollByUsingJavaScript() {
		// TODO Auto-generated method stub
		
	}
	private void waitTillElementVisible(WebElement country_Dpdn2) {
		// TODO Auto-generated method stub
		
	}
	public void click_Continue() {
		try {
			Thread.sleep(1000);
			checkElementIsVisible(continue_Btn);
			continue_Btn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void checkElementIsVisible(WebElement continue_Btn2) {
		// TODO Auto-generated method stub
		
	}
	public void click_Settings() {
		try {
			settings_Btn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
