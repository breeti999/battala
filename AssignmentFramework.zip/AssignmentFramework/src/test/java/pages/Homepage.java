package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class Homepage extends BaseClass {
	public Homepage(RemoteWebDriver driver)
	{
		this.driver =driver;
	PageFactory.initElements(driver, this);
	}
	@FindBy(id = "okta-signin-submit")
	WebElement loginMenu; // WebElement after that you can give one name 
	@FindBy(xpath = "//input[@value='Send Push']")
	WebElement push; 
	
	// part 2 actions what you are going to do, here clicking is not part of homepage, it is action
	
	public LoginPage clickLogin() 
	{
		clickElement(loginMenu);
		return new LoginPage(driver);
	}
	public LoginPage clickpush() 
	{
		clickElement(push);
		return new LoginPage(driver);
	}

	
	
	
	

}
