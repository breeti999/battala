package pages;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class UserMaintanancePage extends BaseClass{
	public UserMaintanancePage(WebDriver driver) {
	
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@id=\"tools\"]")
	public WebElement clicksetting;
	@FindBy(xpath = "//*[@id=\"USER_ROLE_MAINTENANCE\"]/span[2]")
	public WebElement clickmaintanance;
	@FindBy(id = "fx-gn-user-role-search-userId")
	public WebElement userID_TxtBx;
	

	public user clicksetting()  
	{
		clickElement(clicksetting);
		return new user();
	}
	public user1 clickmaintanance() 
	{
		clickElement(clickmaintanance);
		return new user1();
	}
	
	public void set_UserID(String userID) throws InterruptedException, AWTException {
		waitTillElementVisible(userID_TxtBx);
		userID_TxtBx.sendKeys(userID);
		userID_TxtBx.sendKeys(Keys.RETURN);
	}
	private void waitTillElementVisible(WebElement userID_TxtBx2) {
		// TODO Auto-generated method stub
		
	}
	public void role() {
		// TODO Auto-generated method stub
		
	}
	
	
		
}
	
