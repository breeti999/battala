package stepdefinition;

import java.time.Duration;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import pages.Homepage;
import pages.LoginPage;


public class Login extends BaseClass{
	public Homepage homepage;
	public LoginPage loginPage; 
	@Given("the user in homepage of the application")
public void the_user_in_homepage_of_the_application() throws InterruptedException {
		invokeApp("chrome","https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/dashboard");
		 homepage=new Homepage(driver);
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
  @Then("user fill the login form")
public void user_fill_the_login_form() {
	  loginPage = homepage.clickLogin();
	  
	  loginPage.enterusername("4920519")
		.enterPassword("Mou#ped99@t");
	
    
}
	@Then("user click the login button")
	public void user_click_the_login_button() throws InterruptedException {
		loginPage.clickLoginbutton();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	
		
		
	    
	}
	@Then("user click the sendpush button")
	public void user_click_the_sendpush_button() throws InterruptedException {
		 loginPage = homepage.clickpush();
		 loginPage.pushbutton();
	}
		@Then("user click contextmenu")
		public void user_click_contextmenu() throws InterruptedException {
		loginPage.select_Country();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		loginPage.click_Continue();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		loginPage.click_Continue();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	
}
  

