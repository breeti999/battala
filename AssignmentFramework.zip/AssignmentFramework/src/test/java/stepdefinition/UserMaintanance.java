package stepdefinition;

import java.awt.AWTException;
import java.time.Duration;

import base.BaseClass;

import io.cucumber.java.en.Then;

import pages.UserMaintanancePage;

public class UserMaintanance extends BaseClass {
	public UserMaintanancePage userMaintanance; 
	
 	UserMaintanancePage maintanance;
	@Then("user click setting icon")
	public void user_click_setting_icon() {
		
		maintanance = new UserMaintanancePage(driver);
		maintanance.clicksetting();
		
	}
	
	@Then("user select usermaintenance icon")
	public void user_select_setting_icon() {
		maintanance.clickmaintanance();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	@Then("Search for User {string}")
	public void search_for_user(String userID) throws AWTException, InterruptedException {
		maintanance.set_UserID(userID);

	}
	@Then("validate the success message")
	public void validate_the_success_message() {
	    String pageTitle = getTitle();
	    System.out.println(pageTitle);
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	@Then("close the application")
	public void close_the_application() {
	    driver.close();
	}
    

}
